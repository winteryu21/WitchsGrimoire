using System.Collections.Generic;
using UnityEngine;

public class PlayerSkills : MonoBehaviour
{
    public List<SkillSlot> activeSkills = new List<SkillSlot>();
    public int maxSkillCount = 6;

    public bool LearnSkill(SkillBase skill)
    {
        var slot = activeSkills.Find(s => s.skill.skillId == skill.skillId);
        if (slot != null)
        {
            if (slot.level < skill.maxLevel)
            {
                slot.level++;
                return true;
            }
            return false;
        }
        else if (activeSkills.Count < maxSkillCount)
        {
            activeSkills.Add(new SkillSlot { skill = skill, level = 1 });
            return true;
        }
        return false;
    }

    public bool HasSkill(string skillId) =>
        activeSkills.Exists(s => s.skill.skillId == skillId);
}
