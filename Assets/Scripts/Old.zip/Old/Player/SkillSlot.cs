using UnityEngine;

[System.Serializable]
public class SkillSlot
{
    public SkillBase skill;
    public int level;
}
