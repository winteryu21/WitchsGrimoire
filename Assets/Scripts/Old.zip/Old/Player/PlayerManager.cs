using UnityEngine;

public class PlayerManager : MonoBehaviour
{
    public PlayerController controller;
    public PlayerHealth health;
    public PlayerStats stats;
    public PlayerSkills skills;

    void Start()
    {
        controller = GetComponent<PlayerController>();
        health = GetComponent<PlayerHealth>();
        stats = GetComponent<PlayerStats>();
        skills = GetComponent<PlayerSkills>();
    }

    public void DisableControl()
    {
        controller.enabled = false;  // 움직임 중단
    }
    
    public void ApplyUpgrade(string upgradeId, float value)
    {
        stats.ApplyPassive(upgradeId, value);
    }

    public void GainSkill(SkillBase skill)
    {
        skills.LearnSkill(skill);
    }

    
}
