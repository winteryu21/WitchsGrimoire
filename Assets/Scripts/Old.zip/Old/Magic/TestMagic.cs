using UnityEngine;

[CreateAssetMenu(menuName = "Skills/OrbitingBladeSkill")]
public class TestMagic : SkillBase
{
    public GameObject bladePrefab;
    public int bladeCount = 1;
    public float orbitRadius = 1.5f;

    public override void Activate(GameObject player, int level)
    {
        Debug.Log("Orbiting skill activated!"); // 확인용 로그 추가
        // 한 번만 생성하고 끝냄 (중복 방지용)
        if (player.transform.Find("OrbitBladeRoot") != null)
            return;

        GameObject root = new GameObject("OrbitBladeRoot");
        root.transform.SetParent(player.transform);
        root.transform.localPosition = Vector3.zero;

        for (int i = 0; i < bladeCount; i++)
        {
            float angle = 360f / bladeCount * i;
            GameObject blade = Instantiate(bladePrefab, root.transform);
            OrbitingBlade ob = blade.GetComponent<OrbitingBlade>();
            ob.Initialize(angle, orbitRadius, level);
        }
    }
}
