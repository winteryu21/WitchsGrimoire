using UnityEngine;

public class SkillTestStarter : MonoBehaviour
{
    public SkillBase testSkill;

    void Start()
    {
        var player = FindObjectOfType<PlayerManager>();
        if (player != null)
        {
            player.GainSkill(testSkill);
        }
    }
}
