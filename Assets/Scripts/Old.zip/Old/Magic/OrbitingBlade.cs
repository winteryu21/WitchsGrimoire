using UnityEngine;

public class OrbitingBlade : MonoBehaviour
{
    public float rotationSpeed = 100f;
    public int damage;

    private float angleDeg;
    private float radius;

    public void Initialize(float startAngle, float orbitRadius, int level)
    {
        angleDeg = startAngle;
        radius = orbitRadius;
        damage = level * 10;
    }

    void Update()
    {
        angleDeg += rotationSpeed * Time.deltaTime;
        float rad = angleDeg * Mathf.Deg2Rad;
        Vector3 offset = new Vector3(Mathf.Cos(rad), Mathf.Sin(rad), 0f) * radius;
        transform.localPosition = offset;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        /*
        if (other.CompareTag("Enemy"))
        {
            var enemy = other.GetComponent<EnemyHealth>();
            if (enemy != null)
                enemy.TakeDamage(damage);
        }
        */
    }
}
