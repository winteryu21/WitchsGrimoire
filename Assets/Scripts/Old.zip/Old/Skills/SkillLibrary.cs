using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(menuName = "Skills/SkillLibrary")]
public class SkillLibrary : ScriptableObject
{
    public List<SkillBase> allSkills;
}
