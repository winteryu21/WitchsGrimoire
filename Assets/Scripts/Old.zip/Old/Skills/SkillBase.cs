using UnityEngine;

public abstract class SkillBase : ScriptableObject
{
    public string skillId;
    public string skillName;
    public Sprite icon;
    public int maxLevel = 5;

    public abstract void Activate(GameObject player, int level);
}
