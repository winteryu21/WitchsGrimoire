using UnityEngine;

public class SkillManager : MonoBehaviour
{
    private PlayerSkills playerSkills;
    private float tick = 1f;
    private float timer;

    void Start()
    {
        playerSkills = GetComponent<PlayerManager>()?.skills;
    }

    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= tick)
        {
            timer = 0f;
            foreach (var slot in playerSkills.activeSkills)
            {
                slot.skill.Activate(gameObject, slot.level);
            }
        }
    }
}
